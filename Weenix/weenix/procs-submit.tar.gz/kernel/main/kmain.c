#include "types.h"
#include "globals.h"
#include "kernel.h"

#include "util/gdb.h"
#include "util/init.h"
#include "util/debug.h"
#include "util/string.h"
#include "util/printf.h"

#include "mm/mm.h"
#include "mm/page.h"
#include "mm/pagetable.h"
#include "mm/pframe.h"

#include "vm/vmmap.h"
#include "vm/shadow.h"
#include "vm/anon.h"

#include "main/acpi.h"
#include "main/apic.h"
#include "main/interrupt.h"
#include "main/cpuid.h"
#include "main/gdt.h"

#include "proc/sched.h"
#include "proc/proc.h"
#include "proc/kthread.h"

#include "drivers/dev.h"
#include "drivers/blockdev.h"
#include "drivers/tty/virtterm.h"

#include "api/exec.h"
#include "api/syscall.h"

#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/fcntl.h"
#include "fs/stat.h"

#include "test/kshell/kshell.h"

GDB_DEFINE_HOOK(boot)
GDB_DEFINE_HOOK(initialized)
GDB_DEFINE_HOOK(shutdown)

static void      *bootstrap(int arg1, void *arg2);
static void      *idleproc_run(int arg1, void *arg2);
static kthread_t *initproc_create(void);
static void      *initproc_run(int arg1, void *arg2);
static void       hard_shutdown(void);
static void      *dummy_func1(int arg1, void *arg2);
static void      *dummy_func2(int arg1, void *arg2);
static void      *dummy_func3(int arg1, void *arg2);
static void      *dummy_func4(int arg1, void *arg2);
static context_t bootstrap_context;

#define CASE      1


int x = 0;

/**
 * This is the first real C function ever called. It performs a lot of
 * hardware-specific initialization, then creates a pseudo-context to
 * execute the bootstrap function in.
 */
void
kmain()
{
        GDB_CALL_HOOK(boot);

        dbg_init();
        dbgq(DBG_CORE, "Kernel binary:\n");
        dbgq(DBG_CORE, "  text: 0x%p-0x%p\n", &kernel_start_text, &kernel_end_text);
        dbgq(DBG_CORE, "  data: 0x%p-0x%p\n", &kernel_start_data, &kernel_end_data);
        dbgq(DBG_CORE, "  bss:  0x%p-0x%p\n", &kernel_start_bss, &kernel_end_bss);

        page_init();

        pt_init();
        slab_init();
        pframe_init();

        acpi_init();
        apic_init();
        intr_init();

        gdt_init();

        /* initialize slab allocators */
#ifdef __VM__
        anon_init();
        shadow_init();
#endif
        vmmap_init();
        proc_init();
        kthread_init();

#ifdef __DRIVERS__
        bytedev_init();
        blockdev_init();
#endif

        void *bstack = page_alloc();
        pagedir_t *bpdir = pt_get();
        KASSERT(NULL != bstack && "Ran out of memory while booting.");
        context_setup(&bootstrap_context, bootstrap, 0, NULL, bstack, PAGE_SIZE, bpdir);
        context_make_active(&bootstrap_context);

        panic("\nReturned to kmain()!!!\n");
}

/**
 * This function is called from kmain, however it is not running in a
 * thread context yet. It should create the idle process which will
 * start executing idleproc_run() in a real thread context.  To start
 * executing in the new process's context call context_make_active(),
 * passing in the appropriate context. This function should _NOT_
 * return.
 *
 * Note: Don't forget to set curproc and curthr appropriately.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
bootstrap(int arg1, void *arg2)
{
        /* necessary to finalize page table information */
        pt_template_init();

        /*NOT_YET_IMPLEMENTED("PROCS: bootstrap");*/


                proc_t  * p = proc_create("IDLE");
                curproc = p;
                kthread_t *t = kthread_create(p, idleproc_run , arg1, arg2);  
                curthr =  t;
                
                KASSERT(NULL != curproc);
                KASSERT(PID_IDLE == curproc->p_pid);
                KASSERT(NULL != curthr);

                context_make_active(&(t->kt_ctx)); 

                panic("weenix returned to bootstrap()!!! BAD!!!\n");
                
                return NULL;
}

/**
 * Once we're inside of idleproc_run(), we are executing in the context of the
 * first process-- a real context, so we can finally begin running
 * meaningful code.
 *
 * This is the body of process 0. It should initialize all that we didn't
 * already initialize in kmain(), launch the init process (initproc_run),
 * wait for the init process to exit, then halt the machine.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
idleproc_run(int arg1, void *arg2)
{
        int status;
        pid_t child;

        /* create init proc */

        kthread_t *initthr = initproc_create();
        
        init_call_all();

        GDB_CALL_HOOK(initialized);

        /* Create other kernel threads (in order) */

#ifdef __VFS__
        /* Once you have VFS remember to set the current working directory
         * of the idle and init processes */

        /* Here you need to make the null, zero, and tty devices using mknod */
        /* You can't do this until you have VFS, check the include/drivers/dev.h
         * file for macros with the device ID's you will need to pass to mknod */
#endif

        /* Finally, enable interrupts (we want to make sure interrupts
         * are enabled AFTER all drivers are initialized) */
        intr_enable();

        /* Run initproc */
        sched_make_runnable(initthr);
        /* Now wait for it */

        child = do_waitpid(-1, 0, &status);
        KASSERT(PID_INIT == child);

#ifdef __MTP__
        kthread_reapd_shutdown();
#endif


#ifdef __VFS__
        /* Shutdown the vfs: */
        dbg_print("weenix: vfs shutdown...\n");
        vput(curproc->p_cwd);
        if (vfs_shutdown())
                panic("vfs shutdown FAILED!!\n");

#endif

        /* Shutdown the pframe system */
#ifdef __S5FS__
        pframe_shutdown();
#endif

        dbg_print("\nweenix: halted cleanly!\n");
        GDB_CALL_HOOK(shutdown);
        hard_shutdown();
        return NULL;
}

/**
 * This function, called by the idle process (within 'idleproc_run'), creates the
 * process commonly refered to as the "init" process, which should have PID 1.
 *
 * The init process should contain a thread which begins execution in
 * initproc_run().
 *
 * @return a pointer to a newly created thread which will execute
 * initproc_run when it begins executing
 */
static kthread_t *
initproc_create(void)
{
           int arg1 = 0;
           void *arg2 = NULL;
           int status;
           proc_t  * p = proc_create("INIT");
           
           KASSERT(NULL != p);
           KASSERT(PID_INIT == p->p_pid);

           kthread_t *t = kthread_create(p, initproc_run , arg1, arg2); 
           KASSERT(t != NULL); 

           return t;      
}

/**
 * The init thread's function changes depending on how far along your Weenix is
 * developed. Before VM/FI, you'll probably just want to have this run whatever
 * tests you've written (possibly in a new process). After VM/FI, you'll just
 * exec "/bin/init".
 *
 * Both arguments are unused.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */

 void case_one();
 void case_two();
 void case_three();
 void case_four();
 void case_five();
 void case_six();
 void case_seven();
 void case_eight();

static void *
initproc_run(int arg1, void *arg2)
{  
        dbg_print("STARTED RUNNING INIT PROCESS\n");

        int status,retval;

        /*We define a variable 'n' for you to select one of our implemented self-checks.
        n = 1 => Test where processes self-exit by calling proc_kill on self.
        n = 2 => Test where one process calls proc_kill() on another.
        n = 3 => Test where one of the processes kills all processes under INIT_PROC by calling proc_kill_all().
        n = 4 => Test for demonstrating re-parenting of child processes to INIT_PROC.
        n = 5 => Test of processes and threads accessing a mutex.
        n = 6 => Test for demonstrating a deadlock on the kernel.
        n = 7 => Test of the PRODUCER-CONSUMER scenario.
        n = 8 => Test for cancellable mutex-lock functionality
        */

         /*PLEASE INITIALIZE CASE TO TEST FOR ANY OF THE ABOVE MENTIONED CASES.*/

        switch(CASE)
        {
            case 1: case_one();
                    break;
            case 2: case_two();
                    break;
            case 3: case_three();
                    break;
            case 4: case_four();
                    break;
            case 5: case_five();
                    break;
            case 6: case_six();
                    break;
            case 7: case_seven();
                    break;
            default:case_eight();
                    break;
        }

        while(!list_empty(&(curproc->p_children)))
            {
                (void)do_waitpid(-1, 0, &status);
            }

          
        proc_kill(curproc, 0); /*EXIT INIT_PROC WITH STATUS = 0*/
        
        return NULL;
}

static void *case_one_func1(int arg1, void *arg2);
static void *case_one_func2(int arg1, void *arg2);
static void *case_one_func3(int arg1, void *arg2);
ktqueue_t ABC;

void
case_one()
{
    dbg_print("RUNNING TEST-CASE 1: Test where processes and threads self-exit\n");

    sched_queue_init(&ABC);

    proc_t *one = proc_create("Process_one");
    kthread_t *one_thr = kthread_create(one, case_one_func1, 0, NULL);
    sched_make_runnable(one_thr);
    dbg_print("PROCESS CREATED: Process_one, added to the runnable queue\n");

    proc_t *two = proc_create("Process_two");
    kthread_t *two_thr = kthread_create(two, case_one_func2, 0, NULL);
    sched_make_runnable(two_thr);
    dbg_print("PROCESS CREATED: Process_two, added to the runnable queue\n");

    proc_t *three = proc_create("Process_three");
    kthread_t *three_thr = kthread_create(three, case_one_func3, 0, NULL);
    sched_make_runnable(three_thr);
    dbg_print("PROCESS CREATED: Process_three, added to the runnable queue\n");

}

static void *case_two_func1(int arg1, void *arg2);
static void *case_two_func2(int arg1, void *arg2);

void
case_two()
{
    dbg_print("RUNNING TEST-CASE 2: Test where one process calls proc_kill() on another\n");

    int retval, status = 0;

    proc_t *one = proc_create("Process_one");
    kthread_t *one_thr = kthread_create(one, case_two_func1, 0, NULL);
    sched_make_runnable(one_thr);
    dbg_print("PROCESS CREATED: Process_one, added to the runnable queue\n");

    proc_t *two = proc_create("Process_two");
    kthread_t *two_thr = kthread_create(two, case_two_func2, 0, NULL);
    sched_make_runnable(two_thr);
    dbg_print("PROCESS CREATED: Process_two, added to the runnable queue\n");

}

static void *case_three_func1(int arg1, void *arg2);
static void *case_three_func2(int arg1, void *arg2);
static void *case_three_func3(int arg1, void *arg2);
static void *case_three_func4(int arg1, void *arg2);

ktqueue_t BCA;

proc_t *p1;
proc_t *p2;
proc_t *p3;
proc_t *p4;

void
case_three()
{
    int status;
    dbg_print("Running TEST 3: Test where one of the processes kills all processes under INIT_PROC by calling proc_kill_all().\n");

    sched_queue_init(&BCA);

    p1=proc_create("Process_1\n");
    kthread_t *thr_1 = kthread_create(p1,case_three_func1,0,NULL);
    sched_make_runnable(thr_1);
    dbg_print("PROCESS CREATED: Process_1, added to the runnable queue\n");

    p2=proc_create("Process_2\n");
    kthread_t *thr_2 = kthread_create(p2,case_three_func2,0,NULL);
    sched_make_runnable(thr_2);
    dbg_print("PROCESS CREATED: Process_2, added to the runnable queue\n");    

   
}
/*MY CODE*/
static void *
case_three_func1(int arg1, void *arg2)
{

    int status;

    p3=proc_create("Process_1_child1");
    kthread_t *thr_3 = kthread_create(p3,case_three_func3,0,NULL);
    sched_make_runnable(thr_3);
    dbg_print("PROCESS CREATED: Process_1_child1, added to the runnable queue\n");
    

    p4=proc_create("Process_1_child2");
    kthread_t *thr_4 = kthread_create(p4,case_three_func4,0,NULL);
    sched_make_runnable(thr_4);
    dbg_print("PROCESS CREATED: Process_1_child2, added to the runnable queue\n");

    dbg_print("Process 1 waiting for its child to terminate\n");

    int retval=retval;

    while(!list_empty(&(curproc->p_children)))
    {

        /*dbg_print("here--------\n");*/
        retval=do_waitpid(curproc->p_pid, 0, &status);
        break;

    }
    do_exit(0);
    return NULL;
}


static void *
case_three_func3(int arg1, void *arg2)
{

    dbg_print("Inside Process 1 child 1\n");
    dbg_print("Process 1 child 1 sleeping on queue BCA\n");

    sched_sleep_on(&BCA);

    do_exit(0);
    return NULL;

}

static void *
case_three_func2(int arg1, void *arg2)
{

    dbg_print("Inside Process 2 child\n");
    dbg_print("Process 2 child sleeping on queue BCA.\n");
    sched_sleep_on(&BCA);

    do_exit(0);
    return NULL;
}

static void *
case_three_func4(int arg1, void *arg2)
{
    dbg_print("Inise Process 1 child 2\n");
    dbg_print("Process 1 child 2 now calls proc_kill_all function.\n");


    /*sched_broadcast_on(&BCA);*/
    proc_kill_all();

    do_exit(0);

    return NULL;
}


/*MY CODE*/


static void *case_four_func1(int arg1, void *arg2);
static void *case_four_func2(int arg1, void *arg2);
static void *case_four_func3(int arg1, void *arg2);
static void *case_four_func4(int arg1, void *arg2);
ktqueue_t DBZ;

void
case_four()
{
    dbg_print("RUNNING TEST-CASE 4: Test for demonstrating re-parenting of child processes to INIT_PROC\n");

    int retval, status = 0;
    proc_t *p = NULL;
    sched_queue_init(&DBZ);

    proc_t *one = proc_create("Process_one");
    kthread_t *one_thr = kthread_create(one, case_four_func1, 0, NULL);
    sched_make_runnable(one_thr);
    dbg_print("PROCESS CREATED: Process_one, added to the runnable queue\n");

    dbg_print("Child processes of INIT:\n");
    list_iterate_begin(&(proc_lookup(1)->p_children), p, proc_t, p_child_link) {
                dbg_print("%s\n", p->p_comm);
    } list_iterate_end();


}

static void      *case_five_func1(int arg1, void *arg2);
static void      *case_five_func2(int arg1, void *arg2);
static void      *case_five_func3(int arg1, void *arg2);
static void      *case_five_func4(int arg1, void *arg2);
static void      *case_five_func5(int arg1, void *arg2);
kmutex_t lock;
ktqueue_t Wait_For_Two;

void
case_five()
{
    dbg_print("RUNNING TEST-CASE 5: Test of processes and threads accessing a mutex \n");
    kmutex_init(&lock);
    sched_queue_init(&Wait_For_Two);

       proc_t * dummy1 = proc_create("Process_one");
        kthread_t *dummy_thr = kthread_create(dummy1, case_five_func1, 0, NULL);
        sched_make_runnable(dummy_thr); 
         dbg_print("PROCESS CREATED: Process_one, added to the runnable queue\n");
    
}

static void      *case_six_func1(int arg1, void *arg2);
static void      *case_six_func2(int arg1, void *arg2);

kmutex_t locka,lockb;

void
case_six()
{
     dbg_print("RUNNING TEST-CASE 6: Test for demonstrating a deadlock on the kernel.");

     kmutex_init(&locka);
     kmutex_init(&lockb);

        proc_t * dummy1 = proc_create("Process_one");
        kthread_t *dummy_thr = kthread_create(dummy1, case_six_func1, 0, NULL);
        sched_make_runnable(dummy_thr); 
        dbg_print("PROCESS CREATED: Process_one, added to the runnable queue\n");

        proc_t * dummy2 = proc_create("Process_two");
        dummy_thr = kthread_create(dummy2, case_six_func2, 0, NULL);
        sched_make_runnable(dummy_thr);    
        dbg_print("PROCESS CREATED: Process_two, added to the runnable queue\n");

}

ktqueue_t token_bucket;
int tokens = 0, iteration = 15, consumption = 0;;

static void *case_seven_func1(int arg1, void *arg2);
static void *case_seven_func2(int arg1, void *arg2);

void
case_seven()
{
    dbg_print("RUNNING TEST-CASE 7: Test of the PRODUCER-CONSUMER scenario\n");

    int retval, status = 0;
    sched_queue_init(&token_bucket);

    proc_t *one = proc_create("Process_one");
    kthread_t *one_thr = kthread_create(one, case_seven_func1, 0, NULL);
    

    proc_t *two = proc_create("Process_two");
    kthread_t *two_thr = kthread_create(two, case_seven_func2, 0, NULL);
    sched_make_runnable(two_thr);
    dbg_print("PROCESS CREATED: Process_two: Consumer, added to the runnable queue\n");
   
    sched_make_runnable(one_thr);
    dbg_print("PROCESS CREATED: Process_one: Producer, added to the runnable queue\n");
}

static void      *case_eight_func1(int arg1, void *arg2);
static void      *case_eight_func2(int arg1, void *arg2);
static void      *case_eight_func3(int arg1, void *arg2);

kmutex_t lock_it;
ktqueue_t lock_Q;
kthread_t *two_thr;
kthread_t *twow_thr;
kthread_t *twoww_thr;

void
case_eight()
{
    dbg_print("RUNNING TEST-CASE 8: Test of the cancellable mutex functionality\n");
    
    kmutex_init(&lock_it);
    sched_queue_init(&lock_Q);

    proc_t *two = proc_create("Process_one");
    two_thr = kthread_create(two, case_eight_func1, 0, NULL);
    sched_make_runnable(two_thr);
    dbg_print("PROCESS CREATED: Process_one, added to the runnable queue\n");

    proc_t *twow = proc_create("Process_two");
    twow_thr = kthread_create(twow, case_eight_func2, 0, NULL);
    sched_make_runnable(twow_thr);
    dbg_print("PROCESS CREATED: Process_two, added to the runnable queue\n");

    proc_t *twoww = proc_create("Process_three");
    twoww_thr = kthread_create(twoww, case_eight_func3, 0, NULL);
    sched_make_runnable(twoww_thr);
    dbg_print("PROCESS CREATED: Process_three, added to the runnable queue\n");

}

static void *
case_eight_func1(int arg1, void *arg2)
{
    dbg_print("Inside Process_one\n");

    dbg_print("%s trying to lock a cancellable mutex\n", curproc->p_comm);
    
    kmutex_lock_cancellable(&lock_it);
    dbg_print("Mutex locked by %s\n", curproc->p_comm);
    dbg_print("%s putting itself to sleep on a custom Queue lock_Q\n", curproc->p_comm);
    sched_sleep_on(&lock_Q);
    dbg_print("%s woken up from sleep. Unlocking mutex now\n", curproc->p_comm);
    kmutex_unlock(&lock_it);

    dbg_print("Killing all processes\n");

    proc_kill_all();

    return NULL;

}

static void *
case_eight_func2(int arg1, void *arg2)
{
    dbg_print("Inside Process_two\n");

    dbg_print("%s trying to lock a cancellable mutex\n", curproc->p_comm);
    
    kmutex_lock_cancellable(&lock_it);
    dbg_print("Mutex locked by %s\n", curproc->p_comm);
    dbg_print("%s putting itself to sleep on a custom Queue lock_Q\n", curproc->p_comm);
    sched_sleep_on(&lock_Q);
    dbg_print("%s woken up from sleep. Unlocking mutex now\n", curproc->p_comm);
    kmutex_unlock(&lock_it);

    do_exit(0);

    return NULL;

}

static void *
case_eight_func3(int arg1, void *arg2)
{
    dbg_print("Inside Process_three\n");

    dbg_print("%s will now cancel Process_two, which is sleeping on the mutex queue\n", curproc->p_comm);

    sched_cancel(twow_thr);
    sched_wakeup_on(&lock_Q);

    dbg_print("Process_One woken up from sleep, %s going to sleep on custom queue lock_Q\n", curproc->p_comm);
    sched_sleep_on(&lock_Q);

    return NULL;
}

static void *
case_seven_func1(int arg1, void *arg2)
{
    
    dbg_print("Inside Process_one: Producer\n");

    while(1)
    {
        /*int r = RANDOM(1,8);*/
        dbg_print("Adding 1 token to the bucket. ");
        tokens = tokens + 1;
        if(tokens > 10)
            tokens = 10;
        dbg_print("Bucket now has %d tokens\n", tokens);

        /*if(tokens > 4 && tokens < 10)
            {
                dbg_print("Bucket now %d tokens. Consumer can start consuming. Switching context to Consumer\n", tokens);
                if(!sched_queue_empty(&token_bucket))
                    {
                        sched_wakeup_on(&token_bucket);
                        sched_switch();
                    }
                else
                        sched_sleep_on(&token_bucket);

            }*/

        if(tokens >= 10)
        {   
            dbg_print("Bucket now has reached its capacity of %d tokens. Waiting for some tokens to be consumed\n", tokens);
            sched_wakeup_on(&token_bucket);
            sched_sleep_on(&token_bucket);
        }

    }

    return NULL;
}

static void *
case_seven_func2(int arg1, void *arg2)
{

    dbg_print("Inside Process_two: Consumer\n");
    sched_sleep_on(&token_bucket);

    while(1)
    {
        dbg_print("Consuming a Token. ");
        tokens = tokens - 1;
        consumption = consumption + 1;

        dbg_print("Bucket now has %d tokens. Consumption of %d\n", tokens, consumption);

        if(consumption == 25)
        {
            dbg_print("Consumer has consumed 25 tokens. No more tokens needed. Stopping Producer and Consumer now\n");
            break;
        }

        if(tokens == 0)
            {
                dbg_print("Waiting for Producer to produce more tokens\n");
                sched_wakeup_on(&token_bucket);
                sched_sleep_on(&token_bucket);                       
            }

    }

    proc_kill_all();

    return NULL;
}

static void *
case_six_func1(int arg1, void *arg2)
{
    sched_queue_init(&ABC);

    dbg_print("Inside Process_one\n");
   kmutex_lock(&locka);
   dbg_print("Mutex: locka held by %s. Sleeping untill a wakeup call. Then trying to latch mutex lockb \n",curproc->p_comm);
   sched_sleep_on(&ABC);   
   kmutex_lock(&lockb);
   dbg_print("Mutex: lockb held by %s \n",curproc->p_comm); 

   kmutex_unlock(&lockb);
   dbg_print("Mutex: lockb let go by %s \n",curproc->p_comm);     
   kmutex_unlock(&locka); 
   dbg_print("Mutex: locka let go by %s \n",curproc->p_comm);  
   
   do_exit(0);
   return NULL;

}

static void *
case_six_func2(int arg1, void *arg2)
{
   dbg_print("Inside Process_two\n");
   kmutex_lock(&lockb);
   dbg_print("Mutex: lockb held by %s. Waking up Process_one. Trying to latch mutex locka  \n",curproc->p_comm);
   sched_wakeup_on(&ABC);
   kmutex_lock(&locka);
   dbg_print("Mutex: locka held by %s \n",curproc->p_comm); 

   kmutex_unlock(&locka);
   dbg_print("Mutex: locka let go by %s \n",curproc->p_comm); 
   kmutex_unlock(&lockb); 
   dbg_print("Mutex: lockb let go by %s \n",curproc->p_comm); 
   
   do_exit(0);
   return NULL;

}


static void *
case_five_func1(int arg1, void *arg2)
{

    dbg_print("Inside Process_one");   
    proc_t *dummy2 = proc_create("Process_one_child_One");
    kthread_t *dummy_thr2 = kthread_create(dummy2, case_five_func2, 0, NULL);
    sched_make_runnable(dummy_thr2);
    dbg_print("PROCESS CREATED: Process_one_child_One, added to the runnable queue\n");

    /*dbg_print("%s locked the mutex ",curproc->p_comm);*/

    proc_t *dummy5 = proc_create("Process_one_child_Two");
    kthread_t *dummy_thr5 = kthread_create(dummy5, case_five_func5, 0, NULL);
    sched_make_runnable(dummy_thr5);
    dbg_print("PROCESS CREATED: Process_one_child_Two, added to the runnable queue\n");    


    dbg_print("%s trying to lock the mutex\n",curproc->p_comm);
    kmutex_lock(&lock); 
    x = x + 1;
    dbg_print("%s locked the mutex \n",curproc->p_comm);
    kmutex_unlock(&lock);       
    
    dbg_print("%s came out of the mutex lock with x = %d\n",curproc->p_comm,x);
    
    dbg_print("%s initating self-termination\n", curproc->p_comm);
    do_exit(0);

    return NULL;    
}

static void *
case_five_func2(int arg1, void *arg2)
{
        dbg_print("Inside Process_one_child_One\n");
        
        proc_t *dummy3 = proc_create("Process_one_child_one's_child");
        kthread_t *dummy_thr3 = kthread_create(dummy3, case_five_func3, 0, NULL);
        sched_make_runnable(dummy_thr3);
        dbg_print("PROCESS CREATED: Process_one_child_one's_child, added to the runnable queue\n");    


        dbg_print("%s trying to lock the mutex \n",curproc->p_comm);
        kmutex_lock(&lock); 
        dbg_print("%s locked the mutex \n",curproc->p_comm);
        dbg_print("%s waits for Process_one_child_Two to execute first. Sleeping on a custom Queue Wait_For_Two\n",curproc->p_comm);
        sched_sleep_on(&Wait_For_Two);
        x = x + 1;
        kmutex_unlock(&lock);       
        
        dbg_print("%s came out of the mutex lock with x = %d\n",curproc->p_comm,x);
        dbg_print("%s initating self-termination\n", curproc->p_comm);
        
        do_exit(0);
        return NULL;    

}

static void *
case_five_func3(int arg1, void *arg2)
{
        dbg_print("Process_one_child_one's_child\n");
        
        proc_t *dummy4 = proc_create("Process_one_child_one's_Grandchild");
        kthread_t *dummy_thr4 = kthread_create(dummy4, case_five_func4, 0, NULL);
        sched_make_runnable(dummy_thr4);
        dbg_print("PROCESS CREATED: Process_one_child_one's_Grandchild, added to the runnable queue\n");    

        dbg_print("%s trying to lock the mutex \n",curproc->p_comm);
        kmutex_lock(&lock); 
        x = x + 1;
        dbg_print("%s locked the mutex \n",curproc->p_comm);
        kmutex_unlock(&lock);       
        dbg_print("%s came out of the mutex lock with x = %d\n",curproc->p_comm,x);
        dbg_print("%s initating self-termination\n", curproc->p_comm);
        
        do_exit(0);
        return NULL;    
}

static void *
case_five_func4(int arg1, void *arg2)
{
    dbg_print("In Process_one_child_one's_Grandchild\n");

    dbg_print("process %s trying to lock the mutex\n",curproc->p_comm);
    kmutex_lock(&lock); 
    x = x + 1;
    dbg_print("process %s locked the mutex \n",curproc->p_comm);
    kmutex_unlock(&lock);       
    
    dbg_print("process %s came out of the mutex lock with x = %d\n",curproc->p_comm,x);
    dbg_print("%s initating self-termination\n", curproc->p_comm);
    
    do_exit(0);

    return NULL;
    
}

static void *
case_five_func5(int arg1, void *arg2)
{
    dbg_print("Inside Process_one_child_Two\n");

    dbg_print("Waking up Process_one_child_one, which is waiting for this process to execute\n");
    sched_wakeup_on(&Wait_For_Two);

    dbg_print("%s tried to lock the mutex \n",curproc->p_comm);
    kmutex_lock(&lock); 
    x = x + 1;
    dbg_print("%s locked the mutex \n",curproc->p_comm);
    kmutex_unlock(&lock);       
    
    dbg_print("%s came out of the mutex lock with x = %d\n",curproc->p_comm,x);
    dbg_print("%s initating self-termination\n", curproc->p_comm);
    
    do_exit(0);    
    return NULL; 
    
}

static void *case_one_func1_child1(int arg1, void *arg2);

static void *
case_one_func1(int arg1, void *arg2)
{
    dbg_print("Inside Process_one\n");
    dbg_print("Creating a child process of Process_one and implementing do_waitpid() on it\n");

    int status;
    proc_t *child = proc_create("Process_one_child");
    kthread_t *child_thr = kthread_create(child, case_one_func1_child1, 0, NULL);
    sched_make_runnable(child_thr);
    dbg_print("PROCESS CREATED: Process_one_child, added to the runnable queue\n");

    int retval = do_waitpid(child->p_pid,0,&status);

    dbg_print("Process_one_child succesfully terminated\n");

    /*WAKING UP PROCESS WAITING ON QUEUE ABC*/

    sched_broadcast_on(&ABC);

    dbg_print("Process_two & Process_three woken up from Queue ABC and put in the runnable queue.");
    dbg_print("Process_one releasing processor and waiting on Queue ABC\n");
    
    sched_sleep_on(&ABC);
    
    dbg_print("Process_one in context and initiating self-termination now\n");

    do_exit(0); /*SELF_TERMINATION*/

    return NULL;    
}

static void *
case_one_func1_child1(int arg1, void *arg2)
{
    dbg_print("Inside Process_one_child\n");
    dbg_print("Initiating self-termination via do_exit() call\n");

    do_exit(0);

    return NULL;

}

static void *
case_one_func2(int arg1, void *arg2)
{
    dbg_print("Inside Process_two\n");
    dbg_print("Waiting on Queue ABC for Process_one_child to die\n");
    sched_sleep_on(&ABC);

    dbg_print("Process_two awake and now initiating self-termination via proc_kill() call\n");

    proc_kill(curproc, 0);

    return NULL;    
}

static void *
case_one_func3(int arg1, void *arg2)
{
    dbg_print("Inside Process_three\n");
    dbg_print("Waiting  on Queue ABC for Process_one_child to die\n");
    sched_sleep_on(&ABC);

    dbg_print("Process_three awake and now initiating self-termination via proc_kill() call. Also waking up Process_one\n");
    sched_wakeup_on(&ABC);

    proc_kill(curproc, 0);

    return NULL;    
}

static void *
case_two_func1(int arg1, void *arg2)
{
    dbg_print("Inside Process_one\n");

    proc_t *p = NULL;
    int status = 0;

    list_iterate_begin(&(curproc->p_pproc->p_children), p, proc_t, p_child_link) {
                
    } list_iterate_end();

     dbg_print("Killing Process_two via proc_kill() call\n");

    proc_kill(p, status);

    do_exit(0);

    return NULL;
}

static void *
case_two_func2(int arg1, void *arg2)
{
    dbg_print("Inside Process_two\n");

    dbg_print("Sleeping on its own queue");

    sched_sleep_on(&(curproc->p_wait));

    return NULL;
}

static void *
case_four_func1(int arg1, void *arg2)
{
        
    dbg_print("Inside Process_one.\n");

    int retval, status = 0;
    proc_t *p = NULL;

    proc_t *two = proc_create("Process_two");
    kthread_t *two_thr = kthread_create(two, case_four_func2, 0, NULL);
    sched_make_runnable(two_thr);
    dbg_print("PROCESS CREATED: Process_two, added to the runnable queue\n");

    while(!list_empty(&(curproc->p_children)))
            (void)do_waitpid(-1, 0, &status);

    dbg_print("Child processes of INIT:\n");
    list_iterate_begin(&(curproc->p_pproc->p_children), p, proc_t, p_child_link) {
                dbg_print("%s\n", p->p_comm);
    } list_iterate_end();

    dbg_print("Waking up Process_three & Process_four.\n");
    sched_broadcast_on(&DBZ);

    do_exit(0);

    return NULL;
}

static void *
case_four_func2(int arg1, void *arg2)
{
        
    dbg_print("Inside Process_two\n");

    int retval, status = 0;
    proc_t *three = proc_create("Process_three");
    kthread_t *three_thr = kthread_create(three, case_four_func3, 0, NULL);
    sched_make_runnable(three_thr);
    dbg_print("PROCESS CREATED: Process_three, child of Process_two, added to the runnable queue\n");

    proc_t *four = proc_create("Process_four");
    kthread_t *four_thr = kthread_create(four, case_four_func4, 0, NULL);
    sched_make_runnable(four_thr);
    dbg_print("PROCESS CREATED: Process_four, child of Process_two, added to the runnable queue\n");

    dbg_print("Process_two going to sleep\n");
    sched_sleep_on(&DBZ);

     dbg_print("Initiating self-termination for Process_two. This would trigger re-parenting of Process_three and Process_four\n");
    do_exit(0);

    return NULL;
}

static void *
case_four_func3(int arg1, void *arg2)
{
    
    dbg_print("Inside Process_three.\n");

    proc_t *p = NULL;
    int status = 0;

    dbg_print("Process_three going to sleep.\n");
    sched_sleep_on(&DBZ);

    do_exit(0);

    return NULL;
}

static void *
case_four_func4(int arg1, void *arg2)
{
    
    dbg_print("Inside Process_four.\n");

    proc_t *p = NULL;
    int status = 0;

    dbg_print("Process_four wakes up Process_two and goes to sleep\n");
    sched_wakeup_on(&DBZ);
    sched_sleep_on(&DBZ);

    do_exit(0);

    return NULL;
}


/**
 * Clears all interrupts and halts, meaning that we will never run
 * again.
 */
static void
hard_shutdown()
{
#ifdef __DRIVERS__
        vt_print_shutdown();
#endif
        __asm__ volatile("cli; hlt");
}
